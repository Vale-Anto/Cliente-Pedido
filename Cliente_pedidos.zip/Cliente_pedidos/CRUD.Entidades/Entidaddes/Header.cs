﻿using CRUD.Entidades.Common;

namespace CRUD.Entidades.Entidaddes
{
    internal class Header : EntidadesCommon
    {

        public int ClienteId { get; set; }
        public string nombre { get; set; }
        public string apellido { get; set; }
        public string direccion { get; set; }
        public string codigoPostal { get; set; }
        public string ciudad { get; set; }

    }
}
