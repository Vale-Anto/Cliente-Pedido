﻿namespace CRUD.Entidades.Interfaces.Repositorio
{
    internal class cliente
    {

        Task<Cliente> GetClienteById(int clienteId);
        Task<List<Cliente>> GetClientes();
        Task<Cliente> CreateCliente(Cliente cliente);
        Task<Cliente> UpdateCliente(Cliente cliente);
        Task<Cliente> DeleteCliente(int clienteId);

    }
}
