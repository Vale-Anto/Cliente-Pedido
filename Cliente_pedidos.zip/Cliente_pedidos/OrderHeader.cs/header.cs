﻿
namespace Header.cs

    public class header

{
    public int ClienteId { get; set; }
    public string nombre { get; set; }
    public string apellido { get; set; }
    public string direccion { get; set; }
    public string codigoPostal { get; set; }
    public string ciudad { get; set; }

}
}